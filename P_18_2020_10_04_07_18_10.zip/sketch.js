
var backimg,screen,monkey,monkeyrunning,banana,bananaimg,stone,stoneimg

function preload() {
 backimg = loadImage("jungle.jpg");
  monkeyrunning = loadAnimation('Monkey_01.png','Monkey_02.png','Monkey_03.png','Monkey_04.png','Monkey_05.png','Monkey_06.png','Monkey_07.png','Monkey_08.png','Monkey_09.png','Monkey_10.png');
 }

function setup() {
  createCanvas(600, 200);
  screen = createSprite (300,100,600,200);
    monkey = createSprite(300,100,10,10);
    monkey.addAnimation("running",monkeyrunning);
}

function draw() {
  background(290);
  
  
  //drawSprites();
}